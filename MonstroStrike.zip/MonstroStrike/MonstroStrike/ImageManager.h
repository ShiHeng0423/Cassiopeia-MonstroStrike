#pragma once
#include "Inventory.h"

void ImageInit(const int item);
