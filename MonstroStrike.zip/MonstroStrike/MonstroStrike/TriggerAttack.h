#pragma once
#include "Player.h"

void *TriggerAttack(Player& player);