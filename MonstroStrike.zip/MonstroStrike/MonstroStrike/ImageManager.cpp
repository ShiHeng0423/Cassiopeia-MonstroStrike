#include "ImageManager.h"


void ImageInit(const int item)
{
	UNREFERENCED_PARAMETER(item);
}
